---
layout: default
title: Release 0.1.0
---

JHipster release 0.1.0
==================

JHipster now has a new home on [http://jhipster.github.io/](http://jhipster.github.io/)!

We have also moved the JHipster github repository to the newly created JHipster Github organization:

[https://github.com/jhipster](https://github.com/jhipster)

So please:

- Update your bookmarks
- If you have forked JHipster, update your remote origin:

```
git remote set-url origin https://github.com/jhipster/generator-jhipster.git
```
