---
date: 2011-01-27 12:02:44 UTC
layout: post
slug: going-to-phpbenelux
title: "Going to PHPBenelux"
tags:
  - phpbenelux

---
<p><a href="http://conference.phpbenelux.eu/2011/"><img alt="PHP-BENELUX-Logo.preview.png" src="/blog/user/files/logos/PHP-BENELUX-Logo.preview.png" style="width: 160px; height: 62px; float: left" /></a></p>

<p>Thanks to my <a href="http://www.ibuildings.nl/">awesome employer</a>, I'll be heading to the <a href="http://conference.phpbenelux.eu/2011/">PHPBenelux</a> conference in Antwerp this weekend. Even though I've been doing PHP stuff for a bit, this is actually the first time I'm going to a PHP-specific conference. The schedule looks pretty interesting, so I'll be pretty busy.</p>

<p>If you're going and want to say hi or drink some beers friday or saturday, <a href="/blog/about">drop me a line!</a></p>
