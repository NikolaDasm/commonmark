---
date: 2011-05-25 21:53:11 UTC
layout: post
slug: blogging-for-5-years
title: "Blogging for 5 years"
tags:
  - metablogging

---
<p>Well, I just checked my calendar and it turns out I've been blogging for exactly 5 years now. This is the only time I allow myself to make an off-topic post, so here goes:</p>

<p>An exciting year indeed, with lots of change. Moved back from Korea to the Netherlands, started a new job, spoke at a <a href="http://www.phpconference.nl/">conference</a>, and I've met lots of bright and interesting people.</p>

<p>I've been royally sucking at blogging though. Only 22 posts in the entire year. Worst year to date :) I really should get back into the game, but I steadily feel that the things I'm running into from day to day becomes less relevant to blog about, as there has usually been someone else with a much better description of what I'm really trying to say.</p>

<p>Maybe that's just an excuse though.. If you're still reading, thanks for sticking with me!</p>
