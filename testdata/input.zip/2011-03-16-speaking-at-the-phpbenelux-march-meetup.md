---
date: 2011-03-16 11:59:04 UTC
layout: post
slug: speaking-at-the-phpbenelux-march-meetup
title: "Speaking at the PHPBenelux march meetup"
tags:
  - webdav
  - sabredav
  - phpbenelux
  - talk

---
<p><a href="http://www.phpbenelux.eu/nl/node/1496"><img alt="PHP-BENELUX-Logo.preview.png" src="/blog/user/files/logos/PHP-BENELUX-Logo.preview.png" style="width: 160px; height: 62px; float: left" /></a></p>

<p>I'll be speaking the next PHPBenelux meetup in Amersfoort about implementing WebDAV using PHP. Joshua Thijssen will also be doing a talk about MySQL optimization. The meetups are free, so if you have some time after work, drop by and say hi. You can sign up at the <a href="http://www.phpbenelux.eu/nl/node/1496">PHPBenelux site</a>.</p>
