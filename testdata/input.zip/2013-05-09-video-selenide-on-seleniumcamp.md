---
layout: post
title: "Video: Selenide on SeleniumCamp 2013"
description: "Selenide on SeleniumCamp 2013"
category: 
tags: []
---
{% include JB/setup %}

This is our talk about Selenide on [SeleniumCamp 2013](http://seleniumcamp.com/materials/) conference in Kiev.

The talk is in Russian.


First part - introduction to Selenide:
<div class="video"><iframe width="800" height="490" frameborder="0" src="http://video.yandex.ru/iframe/xpinjection/jaij48yhjf.3916/"></iframe></div>

Second part - live demonstration of Selenide:

*   pair programming
*   ping-pong programming
*   programming a real internet bank

<div class="video"><iframe width="800" height="490" frameborder="0" src="http://video.yandex.ru/iframe/xpinjection/stvbyavn8a.2128/"></iframe></div>