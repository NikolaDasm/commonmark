---
date: 2011-10-10 15:13:50 UTC
layout: post
slug: moved-sabredav-to-github
title: "Moved SabreDAV to Github"
tags:
  - sabredav
  - mercurial
  - github
  - git

---
<p>I've finally taken the plunge and moved the <a href="http://sabre.io/">SabreDAV</a> source from Google code to <a href="https://github.com/fruux/sabre-dav/">GitHub</a>.</p>

<p>The main reason is that I'm hoping that people are more likely to fork and contribute. This was possible as well on googlecode, but I think people had a bit more trouble getting used to the feature.</p>

<p><a href="http://mercurial.selenic.com/">Mercurial</a> is still the best source control system, but I feel switching to Git was worth it, solely for GitHub.</p>

<p>You can find the source at <a href="https://github.com/fruux/sabre-dav">https://github.com/fruux/sabre-dav</a>.</p>
