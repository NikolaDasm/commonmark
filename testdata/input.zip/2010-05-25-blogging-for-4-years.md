---
date: 2010-05-25 14:58:43 UTC
layout: post
slug: blogging-for-4-years
title: "Blogging for 4 years"
tags:
  - metablogging

---
<p>I've been blogging for 4 years now, so it's time for some reflection.</p>

<p>This year I've been able to crank out a mere 40 blog-posts. Compared to 50 in the year before, and 54 before that it appears there's a year-over-year decline. One can only hope that the quality went up to make up for it.</p>

<p>Some crazy changes have happened in my life and I ended up moving from Toronto, Canada to the Netherlands and now in Daegu, South Korea. I switched from a full-time job to freelancing and from a crappy old custom blog to <a href="http://habariproject.org/">Habari</a>. All good choices so far =).</p>

<p>Thanks for reading and commenting!</p>
