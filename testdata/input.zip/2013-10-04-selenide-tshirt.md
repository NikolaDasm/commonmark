---
layout: post
title: "Selenide T-shirt"
description: ""
category: 
tags: []
---
{% include JB/setup %}

Hi seleniders!

You could have noticed that Selenide has got a new logo and design.

And even own T-shirts! Like real men!

We will share three of these T-shirts next week on the [XP Days conference](http://xpdays.com.ua/program/) in Kiev.

[![front]({{ BASE_PATH }}/images/2013/10/selenide_front.thumb.jpg)]({{ BASE_PATH }}/images/2013/10/selenide_front.jpg)
[![back]({{ BASE_PATH }}/images/2013/10/selenide_back.thumb.jpg)]({{ BASE_PATH }}/images/2013/10/selenide_back.jpg)