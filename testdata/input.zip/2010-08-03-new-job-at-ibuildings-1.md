---
date: 2010-08-03 20:37:04 UTC
layout: post
slug: new-job-at-ibuildings-1
title: "New job at IBuildings"
tags:
  - job
  - ibuildings

---
<div style="float: left"><a href="http://www.ibuildings.co.uk"><img alt="IBuildings" src="http://evertpot.com/resources/files/logos/ibuildings_logo_small.jpg" width="236" height="57" /></a></div>

<p>Since a 2 weeks I'm now employed by <a href="http://www.ibuildings.co.uk/">IBuildings</a>. First a couple of weeks from their office in Vlissingen, and then if all goes well, to Utrecht.</p>

<p>IBuildings is actually a company I've been wanting to work for for a while, so I'm pretty happy. So far it's a bit of an adjustment to work regular hours again, but I'm having fun. It's good to be working in an office again. Working from home can definitely get to you after a while. Having lots of talented people around is a big plus.</p>

<p>And: if you know a good place to live in Utrecht, drop me a line! I'm looking to rent a place not too far from downtown :)</p>
