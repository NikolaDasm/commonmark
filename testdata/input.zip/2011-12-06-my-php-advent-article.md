---
date: 2011-12-06 21:31:56 UTC
layout: post
slug: my-php-advent-article
title: "My PHP Advent article"
tags:
  - php
  - datetime
  - phpadvent

---
<p>
My <a href="http://phpadvent.org/2011/dates-and-times-by-evert-pot">PHP Advent</a> article just got published. It's a list of best practices around dealing with dates and times in PHP. Have a read and tell me what you think. Also, be sure to follow <a href="https://twitter.com/#!/phpadvent">@phpadvent</a> or <a href="http://feeds.feedburner.com/phpadvent">subscribe</a>.
</p>
