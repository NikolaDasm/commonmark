---
date: 2011-10-07 11:53:39 UTC
layout: post
slug: timezone-database-closed-down
title: "Timezone database closed down"
tags:
  - datetime
  - timezones
  - olson

---
<p>Interesting news today. The Olson database, which is used in countless operating systems and other software (including PHP) has been shut down due to a Copyright claim.</p>

<p>Details, which I won't repeat here can be found on <a href="http://blog.joda.org/2011/10/today-time-zone-database-was-closed.html?m=1">Stephen Colbourne's blog.</a></p>

