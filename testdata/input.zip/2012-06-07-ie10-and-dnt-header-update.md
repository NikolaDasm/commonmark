---
date: 2012-06-07 16:30:11 UTC
layout: post
slug: ie10-and-dnt-header-update
title: "IE10 and DNT-header update"
tags:
  - ie
  - privacy
  - dnt

---
<p>A quick update, since my last post Microsoft has reverted it's decision to enable the DNT header by default. I sort of expected this, and I'm glad they did.</p>

<p><a href="http://arstechnica.com/information-technology/2012/06/ie-10s-do-not-track-default-dies-quick-death/">Ars Technica</a> has the details.</p>
