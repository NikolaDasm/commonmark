---
layout: post
title: "Selenide Harlem Shake"
description: ""
category: 
tags: []
---
{% include JB/setup %}

Good morning!

This is a video demonstrating how easy is to start writing automated tests with Selenide.

We wanted to make a screencast that would be short, funny and informative enough. By the way, this is a real-life project, not another "Hello World" application.

Watch with sound!

<iframe src="//player.vimeo.com/video/73128965" width="500" height="281" frameborder="0" webkitallowfullscreen="" mozallowfullscreen="" allowfullscreen="">
</iframe>

<p>
  <a href="http://vimeo.com/73128965">Selenide Harlem Shake</a> from
  <a href="http://vimeo.com/user20427140">Selenide</a> on
  <a href="https://vimeo.com">Vimeo</a>.
</p>