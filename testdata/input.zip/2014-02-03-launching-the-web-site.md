---
layout: post
title:  "Launching the Web Site"
date:   2014-02-03 13:00:00
author: jduck
categories: news
---

In May 2012, after engaging in a long-term consulting project regarding Android, I realized a need to build a community in order to advance the security of the Android mobile platform. To begin the process, I joined an IRC channel and invited likeminded people to join. Today, over sixty people participate in the channel. 

Launching this web site, and the accompanying Wiki, signifies the next step in the evolution of the group. We hope that by organizing ourselves and making regular contributions we can make the Android platform more secure while still remaining open. We have several projects in the works and we hope to showcase them here when the time is right. Stay tuned!

