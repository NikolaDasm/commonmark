---
layout: default
title: Release 0.2.1
---

JHipster release 0.2.1
==================

*JHipster gives you Yeoman + Maven + Spring + AngularJS all working together in one handy generator.*

This is mostly a bug-fix release, which corrects an error occuring when using Grunt on Windows, due to a bug in the grunt-contrib-imagemin NPM package.
